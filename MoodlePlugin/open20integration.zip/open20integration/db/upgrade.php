<?php

defined('MOODLE_INTERNAL') || die();

function xmldb_local_open20integration_upgrade($oldversion){
    return true;
}