<?php
$plugin->component = 'local_open20integration';
// Versione del plugin
$plugin->version  = 2018041607;
// Versione minima di Moodle richiesta
$plugin->requires = 2017111300;
