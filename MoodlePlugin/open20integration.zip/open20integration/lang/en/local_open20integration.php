<?php

$string['pluginname'] = 'Open 2.0 Integration';